# CART3R CHESS ANALYZER — v1.1.0

Aplicación Android nativa Kotlin + Jetpack Compose. Permite analizar posiciones FEN y partidas PGN importadas manualmente con Stockfish en el dispositivo.

## Requisitos
- Android Studio (versión reciente)
- JDK 17
- Android SDK 35
- Python 3 para descargar el motor
- Teléfono Android ARM64 (la integración preparada en esta entrega es ARM64)

## Preparar Stockfish
Desde la raíz del proyecto ejecutá:

```bash
python scripts/setup_engine.py
```

El script descarga el ZIP ARM64 de la release estable oficial Stockfish 19, extrae el ejecutable y lo coloca en `app/src/main/jniLibs/arm64-v8a/libstockfish.so`. El binario se empaqueta para que Android lo extraiga y la aplicación lo ejecute localmente.

La release oficial puede consultarse en:
https://github.com/official-stockfish/Stockfish/releases/tag/sf_19

## Abrir y compilar
1. Ejecutá el script anterior.
2. Android Studio → Open → seleccioná la carpeta del proyecto.
3. Esperá la sincronización de Gradle.
4. Build → Build Bundle(s) / APK(s) → Build APK(s).
5. La APK debug queda en `app/build/outputs/apk/debug/app-debug.apk`.

También se incluye `.github/workflows/android.yml`: si subís el proyecto a un repositorio GitHub y ejecutás el workflow, descarga Stockfish y compila la APK como artefacto.

## Funciones
- Entrada FEN y validación mediante chesslib.
- Entrada PGN y reproducción de la partida para obtener su posición final.
- Análisis UCI local con Stockfish.
- Profundidad configurable.
- Mejor movimiento y tres variantes principales.
- Evaluación en peones o mate.
- Sin conexión de partidas a servidores externos.

## Límites
- Esta compilación está preparada para ARM64 (`arm64-v8a`). Para teléfonos x86_64 o ARMv7 hay que añadir el binario correspondiente y la selección de ABI.
- No detecta automáticamente una partida abierta en Chess.com, no superpone sugerencias y no realiza movimientos en sitios de juego. Está diseñada para análisis manual y estudio.
- El binario de Stockfish se descarga aparte porque es un ejecutable de terceros de gran tamaño.

## Licencias
Stockfish se distribuye bajo GPLv3. Al redistribuir una APK que lo incluya, conservá los avisos de copyright y proporcioná el código fuente correspondiente y los términos GPLv3. Consultá `https://github.com/official-stockfish/Stockfish` y la licencia incluida en la release. chesslib tiene su propia licencia; revisá su repositorio antes de distribuir.
