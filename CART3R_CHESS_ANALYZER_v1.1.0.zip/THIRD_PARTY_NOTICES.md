# Third-party notices

- Stockfish: GPL-3.0. Source and license: https://github.com/official-stockfish/Stockfish
- chesslib: review the license at https://github.com/bhlangonijr/chesslib before redistribution.

The Stockfish binary is fetched separately by `scripts/setup_engine.py`; the upstream license and corresponding source must accompany redistributed builds.
