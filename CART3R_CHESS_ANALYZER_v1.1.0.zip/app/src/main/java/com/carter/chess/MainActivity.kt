package com.carter.chess

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.github.bhlangonijr.chesslib.Board
import com.github.bhlangonijr.chesslib.move.Move
import com.github.bhlangonijr.chesslib.move.MoveList
import com.github.bhlangonijr.chesslib.pgn.PgnHolder
import kotlinx.coroutines.launch
import java.util.Locale

private val Bg = Color(0xFF080808)
private val Panel = Color(0xFF151015)
private val Red = Color(0xFFFF3045)
private val Muted = Color(0xFFB9AEB1)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { Cart3rApp(applicationInfo.nativeLibraryDir) }
    }
}

@Composable
fun Cart3rApp(nativeLibraryDir: String) {
    var fen by remember { mutableStateOf("rnbqkbnr/pppppppp/8/8/8/8/PPPPPPPP/RNBQKBNR w KQkq - 0 1") }
    var pgn by remember { mutableStateOf("") }
    var result by remember { mutableStateOf("Importá una posición FEN o una partida PGN para analizarla.") }
    var tab by remember { mutableIntStateOf(0) }
    var depth by remember { mutableFloatStateOf(15f) }
    var busy by remember { mutableStateOf(false) }
    var lines by remember { mutableStateOf<List<EngineLine>>(emptyList()) }
    var bestMove by remember { mutableStateOf("") }
    var engineName by remember { mutableStateOf("Stockfish no iniciado") }
    val scope = rememberCoroutineScope()

    MaterialTheme(colorScheme = darkColorScheme(
        background = Bg, surface = Panel, primary = Red,
        onBackground = Color.White, onSurface = Color.White
    )) {
        Column(
            Modifier.fillMaxSize().background(Bg).verticalScroll(rememberScrollState()).padding(18.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            Text("♟ CART3R", color = Red, fontSize = 27.sp, fontWeight = FontWeight.Black)
            Text("CHESS ANALYZER  /  OFFLINE ENGINE", color = Muted, fontSize = 11.sp, letterSpacing = 2.sp)
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                FilterChip(selected = tab == 0, onClick = { tab = 0 }, label = { Text("POSICIÓN FEN") })
                FilterChip(selected = tab == 1, onClick = { tab = 1 }, label = { Text("PARTIDA PGN") })
            }
            if (tab == 0) {
                Text("POSICIÓN FEN", color = Red, fontWeight = FontWeight.Bold)
                InputBox(fen, { fen = it }, "Pegá aquí la posición FEN", 3)
            } else {
                Text("PARTIDA PGN", color = Red, fontWeight = FontWeight.Bold)
                InputBox(pgn, { pgn = it }, "Pegá aquí la partida PGN completa", 9)
                Button(
                    onClick = {
                        runCatching { pgnToFen(pgn) }
                            .onSuccess { fen = it; result = "Partida PGN cargada. Se analizará la posición final." }
                            .onFailure { result = "No se pudo leer el PGN: ${it.message}" }
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF3A2026)),
                    modifier = Modifier.fillMaxWidth()
                ) { Text("CARGAR POSICIÓN FINAL DEL PGN") }
                Text("El PGN se reproduce desde el inicio y se analiza la posición final de la partida.", color = Muted, fontSize = 11.sp)
            }

            Text("PROFUNDIDAD: ${depth.toInt()}", color = Red, fontWeight = FontWeight.Bold)
            Slider(value = depth, onValueChange = { depth = it }, valueRange = 8f..22f, steps = 13, colors = SliderDefaults.colors(thumbColor = Red, activeTrackColor = Red))
            Button(
                onClick = {
                    scope.launch {
                        busy = true
                        lines = emptyList()
                        bestMove = ""
                        result = "Stockfish está analizando..."
                        try {
                            validateFen(fen)
                            val analysis = StockfishEngine(nativeLibraryDir).analyze(fen.trim(), depth.toInt(), 3)
                            engineName = analysis.engineName
                            bestMove = analysis.bestMove
                            lines = analysis.lines
                            result = "Análisis terminado. Mejor jugada: ${analysis.bestMove}"
                        } catch (e: Exception) {
                            result = e.message ?: "Error durante el análisis."
                        } finally {
                            busy = false
                        }
                    }
                },
                enabled = !busy,
                colors = ButtonDefaults.buttonColors(containerColor = Red, disabledContainerColor = Color.DarkGray),
                modifier = Modifier.fillMaxWidth()
            ) {
                if (busy) CircularProgressIndicator(Modifier.size(18.dp), color = Color.White, strokeWidth = 2.dp)
                else Text("ANALIZAR CON STOCKFISH", fontWeight = FontWeight.Bold)
            }

            Card(colors = CardDefaults.cardColors(containerColor = Panel), shape = RoundedCornerShape(16.dp)) {
                Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text("RESULTADO DEL MOTOR", color = Red, fontWeight = FontWeight.Bold, letterSpacing = 1.sp)
                    Text(result, color = Color.White, fontSize = 14.sp)
                    if (bestMove.isNotBlank()) {
                        Text("MEJOR JUGADA", color = Muted, fontSize = 11.sp)
                        Text(bestMove, color = Red, fontSize = 28.sp, fontWeight = FontWeight.Black)
                    }
                    if (lines.isNotEmpty()) {
                        Divider(color = Color(0xFF493039))
                        Text("VARIANTES PRINCIPALES", color = Red, fontWeight = FontWeight.Bold)
                        lines.forEach { line ->
                            Column(verticalArrangement = Arrangement.spacedBy(3.dp)) {
                                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                    Text("#${line.multipv}  ${line.score}", color = Color.White, fontWeight = FontWeight.Bold)
                                    Text("Depth ${line.depth}", color = Muted, fontSize = 11.sp)
                                }
                                Text(line.pv, color = Muted, fontSize = 12.sp)
                            }
                        }
                    }
                }
            }
            Text(engineName, color = Muted, fontSize = 11.sp)
            Text("El análisis se ejecuta localmente. No conecta con Chess.com ni juega partidas automáticamente.", color = Muted, fontSize = 11.sp)
            Text("CART3R.JAILBREAK  •  v1.1.0", color = Color.Gray, fontSize = 10.sp)
        }
    }
}

@Composable
private fun InputBox(value: String, onValueChange: (String) -> Unit, hint: String, minLines: Int) {
    Column(Modifier.fillMaxWidth().background(Panel, RoundedCornerShape(12.dp)).padding(12.dp)) {
        if (value.isEmpty()) Text(hint, color = Color.Gray, fontSize = 13.sp)
        BasicTextField(
            value = value, onValueChange = onValueChange,
            modifier = Modifier.fillMaxWidth().heightIn(min = (minLines * 22).dp),
            textStyle = androidx.compose.ui.text.TextStyle(color = Color.White, fontSize = 13.sp)
        )
    }
}

private fun validateFen(input: String) {
    val board = Board()
    board.loadFromFen(input.trim())
    require(board.getFen().isNotBlank()) { "FEN vacío o inválido." }
}

private fun pgnToFen(input: String): String {
    require(input.isNotBlank()) { "El campo PGN está vacío." }
    val holder = PgnHolder()
    holder.loadPgn(input)
    val game = holder.getGames().firstOrNull() ?: error("No se encontró ninguna partida.")
    game.loadMoveText()
    val moves = game.getHalfMoves()
    val board = Board()
    val startFen = moves.getStartFen()
    if (!startFen.isNullOrBlank()) board.loadFromFen(startFen)
    for (move in moves) board.doMove(move)
    return board.getFen()
}
