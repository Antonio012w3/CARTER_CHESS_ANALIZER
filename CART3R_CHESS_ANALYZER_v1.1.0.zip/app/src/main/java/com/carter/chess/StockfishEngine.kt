package com.carter.chess

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.BufferedReader
import java.io.BufferedWriter
import java.io.File
import java.io.InputStreamReader
import java.io.OutputStreamWriter

data class EngineLine(
    val multipv: Int,
    val depth: Int,
    val score: String,
    val pv: String
)

data class EngineResult(
    val bestMove: String,
    val lines: List<EngineLine>,
    val engineName: String
)

class StockfishEngine(private val nativeLibraryDir: String) {
    suspend fun analyze(fen: String, depth: Int = 15, multiPv: Int = 3): EngineResult =
        withContext(Dispatchers.IO) {
            val executable = File(nativeLibraryDir, "libstockfish.so")
            require(executable.exists()) {
                "No se encontró Stockfish para ARM64. Ejecutá primero scripts/setup_engine.py y reconstruí la APK."
            }
            require(executable.canExecute()) {
                "Android no permite ejecutar el motor empaquetado. Revisá la carpeta jniLibs y extractNativeLibs."
            }

            val process = ProcessBuilder(executable.absolutePath)
                .redirectErrorStream(true)
                .start()
            val reader = BufferedReader(InputStreamReader(process.inputStream))
            val writer = BufferedWriter(OutputStreamWriter(process.outputStream))

            fun send(command: String) {
                writer.write(command)
                writer.newLine()
                writer.flush()
            }

            fun readUntil(marker: String): List<String> {
                val collected = mutableListOf<String>()
                var found = false
                var count = 0
                while (count++ < 10000) {
                    val line = reader.readLine() ?: break
                    collected += line
                    if (line.trim() == marker) {
                        found = true
                        break
                    }
                }
                check(found) { "Stockfish no respondió con $marker." }
                return collected
            }

            try {
                send("uci")
                val uciLines = readUntil("uciok")
                val engineName = uciLines.firstOrNull { it.startsWith("id name ") }
                    ?.removePrefix("id name ") ?: "Stockfish"
                send("setoption name Threads value 2")
                send("setoption name Hash value 64")
                send("setoption name MultiPV value $multiPv")
                send("isready")
                readUntil("readyok")
                send("position fen $fen")
                send("go depth $depth")

                val latest = linkedMapOf<Int, EngineLine>()
                var bestMove = ""
                var guard = 0
                while (guard++ < 200000) {
                    val line = reader.readLine() ?: break
                    if (line.startsWith("info ")) {
                        parseInfo(line)?.let { latest[it.multipv] = it }
                    } else if (line.startsWith("bestmove ")) {
                        bestMove = line.split(Regex("\\s+")).getOrNull(1).orEmpty()
                        break
                    }
                }
                check(bestMove.isNotBlank() && bestMove != "(none)") {
                    "Stockfish no encontró una jugada legal. Revisá la posición."
                }
                send("quit")
                EngineResult(bestMove, latest.values.sortedBy { it.multipv }, engineName)
            } finally {
                runCatching { send("quit") }
                runCatching { reader.close() }
                runCatching { writer.close() }
                process.destroy()
            }
        }

    private fun parseInfo(line: String): EngineLine? {
        if (!line.contains(" pv ")) return null
        val tokens = line.split(Regex("\\s+"))
        fun valueAfter(key: String, fallback: String = ""): String {
            val i = tokens.indexOf(key)
            return if (i >= 0 && i + 1 < tokens.size) tokens[i + 1] else fallback
        }
        val depth = valueAfter("depth", "0").toIntOrNull() ?: 0
        val multipv = valueAfter("multipv", "1").toIntOrNull() ?: 1
        val scoreIndex = tokens.indexOf("score")
        val score = if (scoreIndex >= 0 && scoreIndex + 2 < tokens.size) {
            val kind = tokens[scoreIndex + 1]
            val raw = tokens[scoreIndex + 2]
            if (kind == "cp") {
                val cp = raw.toIntOrNull() ?: 0
                val pawns = cp / 100.0
                "%+.2f".format(java.util.Locale.US, pawns)
            } else if (kind == "mate") {
                "M$raw"
            } else "?"
        } else "?"
        val pvIndex = tokens.indexOf("pv")
        val pv = if (pvIndex >= 0 && pvIndex + 1 < tokens.size) {
            tokens.drop(pvIndex + 1).joinToString(" ")
        } else ""
        return EngineLine(multipv, depth, score, pv)
    }
}
