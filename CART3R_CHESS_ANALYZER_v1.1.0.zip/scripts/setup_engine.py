#!/usr/bin/env python3
"""
Downloads the official Stockfish Android ARM64 release binary and installs it
as a packaged executable shared-library payload for Android extraction.
"""
import json, urllib.request, zipfile, io, os, shutil, sys

API = "https://api.github.com/repos/official-stockfish/Stockfish/releases/tags/sf_19"
ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
DEST = os.path.join(ROOT, "app", "src", "main", "jniLibs", "arm64-v8a")
OUT = os.path.join(DEST, "libstockfish.so")

def main():
    req = urllib.request.Request(API, headers={"User-Agent": "CART3R-CHESS-ANALYZER"})
    with urllib.request.urlopen(req, timeout=30) as response:
        release = json.load(response)
    assets = release.get("assets", [])
    candidates = [a for a in assets if "android-armv8" in a["name"].lower() and a["name"].lower().endswith(".zip")]
    if not candidates:
        names = "\n".join(a["name"] for a in assets)
        raise SystemExit("No se encontró el ZIP Android ARMv8 en la release oficial. Assets disponibles:\n" + names)
    asset = candidates[0]
    print("Descargando:", asset["name"])
    request = urllib.request.Request(asset["browser_download_url"], headers={"User-Agent": "CART3R-CHESS-ANALYZER"})
    with urllib.request.urlopen(request, timeout=180) as response:
        archive = response.read()
    with zipfile.ZipFile(io.BytesIO(archive)) as z:
        entries = [n for n in z.namelist() if n and not n.endswith("/") and os.path.basename(n).startswith("stockfish-android-armv8")]
        if not entries:
            entries = [n for n in z.namelist() if n and not n.endswith("/") and "stockfish" in os.path.basename(n).lower()]
        if not entries:
            raise SystemExit("No se encontró el ejecutable Stockfish dentro del ZIP.")
        binary = z.read(entries[0])
    os.makedirs(DEST, exist_ok=True)
    with open(OUT, "wb") as f:
        f.write(binary)
    os.chmod(OUT, 0o755)
    print("Motor instalado en:", OUT)
    print("Tamaño:", len(binary), "bytes")
    print("Ahora abrí Android Studio y compilá la APK.")
if __name__ == "__main__":
    main()
